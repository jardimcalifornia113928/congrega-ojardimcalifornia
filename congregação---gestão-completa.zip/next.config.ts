import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  distDir: 'dist',
  images: {
    unoptimized: true,
  },
  transpilePackages: ["@base-ui/react"],
};

export default nextConfig;
