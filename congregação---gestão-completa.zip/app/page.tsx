'use client';

import React, { useState } from 'react';
import { useAuth } from '@/components/auth-provider';
import { LogIn, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sidebar } from '@/components/sidebar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Dashboard } from '@/components/dashboard';
import { PublishersView } from '@/components/publishers-view';
import { GroupsView } from '@/components/groups-view';
import { MidweekView } from '@/components/midweek-view';
import { WeekendView } from '@/components/weekend-view';
import { FieldReportView } from '@/components/field-report-view';
import { PrintsView } from '@/components/prints-view';
import { SettingsView } from '@/components/settings-view';

export default function Home() {
  const { user, loading, signIn } = useAuth();
  const [activeTab, setActiveTab] = useState('dashboard');

  if (loading) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-slate-50">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="h-screen w-screen flex flex-col items-center justify-center bg-slate-50 p-6">
        <div className="h-20 w-20 rounded-2xl bg-blue-600 flex items-center justify-center text-white font-black text-4xl mb-8 shadow-2xl shadow-blue-600/30">C</div>
        <h1 className="text-4xl font-black mb-3 text-slate-900 tracking-tight">Congregação Jardim Califórnia</h1>
        <div className="flex flex-col items-center mb-8">
          <p className="text-slate-500 font-bold uppercase tracking-widest text-sm">Publicadores</p>
          <div className="h-px w-8 bg-slate-200 my-2" />
          <p className="text-slate-500 font-bold uppercase tracking-widest text-sm">Reuniões</p>
          <div className="h-px w-8 bg-slate-200 my-2" />
          <p className="text-slate-500 font-bold uppercase tracking-widest text-sm">Relatórios</p>
        </div>
        <Button onClick={signIn} size="lg" className="bg-blue-600 text-white hover:bg-blue-700 h-14 px-10 gap-4 font-bold rounded-2xl shadow-xl shadow-blue-600/20 text-lg transition-all hover:scale-105 active:scale-95">
          <LogIn className="h-6 w-6" />
          Entrar com Google
        </Button>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      <Sidebar activeTab={activeTab} onNavigate={setActiveTab} />
      <main className="flex-1 flex flex-col overflow-hidden p-8 lg:p-12">
        <div className="max-w-7xl mx-auto w-full h-full flex flex-col min-h-0">
          {activeTab === 'dashboard' && (
            <ScrollArea className="flex-1 pr-4">
              <Dashboard onNavigate={setActiveTab} />
            </ScrollArea>
          )}
          {activeTab === 'publishers' && <PublishersView />}
          {activeTab === 'groups' && (
            <ScrollArea className="flex-1 pr-4">
              <GroupsView />
            </ScrollArea>
          )}
          {activeTab === 'midweek' && (
            <ScrollArea className="flex-1 pr-4">
              <MidweekView />
            </ScrollArea>
          )}
          {activeTab === 'weekend' && (
            <ScrollArea className="flex-1 pr-4">
              <WeekendView />
            </ScrollArea>
          )}
          {activeTab === 'field' && (
            <ScrollArea className="flex-1 pr-4">
              <FieldReportView />
            </ScrollArea>
          )}
          {activeTab === 'prints' && (
            <ScrollArea className="flex-1 pr-4">
              <PrintsView />
            </ScrollArea>
          )}
          {activeTab === 'settings' && (
            <ScrollArea className="flex-1 pr-4">
              <SettingsView />
            </ScrollArea>
          )}
        </div>
      </main>
    </div>
  );
}
