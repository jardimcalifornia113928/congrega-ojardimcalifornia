import Link from 'next/link';
import { Home } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="h-screen w-screen flex flex-col items-center justify-center bg-slate-50 p-6 text-center">
      <h1 className="text-9xl font-black text-slate-200 mb-4">404</h1>
      <h2 className="text-2xl font-bold text-slate-900 mb-2">Página não encontrada</h2>
      <p className="text-slate-500 mb-8 max-w-md">
        Desculpe, a página que você está procurando não existe ou foi movida.
      </p>
      <Link href="/">
        <button className="bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl h-12 px-8 gap-2 inline-flex items-center justify-center cursor-pointer transition-all">
          <Home className="h-5 w-5" />
          Voltar para o Início
        </button>
      </Link>
    </div>
  );
}
