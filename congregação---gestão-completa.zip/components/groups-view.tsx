'use client';

import React from 'react';
import { 
  UsersRound, 
  Search, 
  Plus, 
  MoreVertical,
  Printer,
  ChevronRight,
  Shield,
  UserPlus,
  X,
  Trash2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { db } from '@/lib/firebase';
import { useAuth } from '@/components/auth-provider';
import { handleFirestoreError, OperationType } from '@/lib/firebase-utils';
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  query, 
  orderBy,
  where,
  deleteDoc,
  doc,
  serverTimestamp
} from 'firebase/firestore';
import { toast } from 'sonner';

export function GroupsView() {
  const [groups, setGroups] = React.useState<any[]>([]);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = React.useState(false);
  const [newGroupName, setNewGroupName] = React.useState("");
  const [isLoading, setIsLoading] = React.useState(true);
  const { user } = useAuth();

  React.useEffect(() => {
    if (!user) {
      setGroups([]);
      setIsLoading(false);
      return;
    }

    const q = query(
      collection(db, 'groups'), 
      where('ownerId', '==', user.uid)
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const groupsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })).sort((a: any, b: any) => (a.name || "").localeCompare(b.name || ""));
      setGroups(groupsData);
      setIsLoading(false);
    }, (error) => {
      console.error("Groups fetch error:", error);
      handleFirestoreError(error, OperationType.LIST, 'groups');
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  const handleCreateGroup = async () => {
    if (!newGroupName.trim() || !user) return;
    const toastId = toast.loading("Criando grupo...");
    
    try {
      await addDoc(collection(db, 'groups'), {
        name: newGroupName,
        count: 0,
        members: [],
        ownerId: user.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      setIsCreateDialogOpen(false);
      setNewGroupName("");
      toast.success("Grupo criado com sucesso!", { id: toastId });
    } catch (error) {
      console.error("Add group error:", error);
      toast.error("Erro ao criar grupo", { id: toastId });
      handleFirestoreError(error, OperationType.CREATE, 'groups');
    }
  };

  const [groupToDelete, setGroupToDelete] = React.useState<{id: string, name: string} | null>(null);

  const handleDeleteGroup = async () => {
    if (!groupToDelete) return;
    const { id, name } = groupToDelete;
    const toastId = toast.loading(`Excluindo ${name}...`);
    try {
      await deleteDoc(doc(db, 'groups', id));
      toast.success("Grupo excluído!", { id: toastId });
      setGroupToDelete(null);
    } catch (error: any) {
      console.error("Delete group error:", error);
      toast.error(`Erro ao excluir: ${error.message || "Erro desconhecido"}`, { id: toastId });
      handleFirestoreError(error, OperationType.DELETE, `groups/${id}`);
    }
  };

  return (
    <div className="space-y-12">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight mb-2">Grupo de Campo</h1>
          <p className="text-slate-500 font-bold">Organização estratégica dos grupos de serviço.</p>
        </div>
        <div className="flex gap-4">
          <Button variant="outline" className="h-12 border-slate-200 text-slate-600 font-bold rounded-xl gap-2 px-6">
            <Printer className="h-4 w-4" />
            Gerar PDF dos Grupos
          </Button>
          
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger render={<Button className="h-12 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg shadow-blue-600/20 px-8" />}>
              <Plus className="h-4 w-4 mr-2" />
              Novo Grupo
            </DialogTrigger>
            <DialogContent className="sm:max-w-md bg-white border-none rounded-[32px] p-8 shadow-2xl">
              <DialogHeader>
                <DialogTitle className="text-2xl font-black text-slate-900 tracking-tight">Criar Novo Grupo</DialogTitle>
                <p className="text-slate-500 font-bold text-sm">Defina um nome para o novo grupo de serviço.</p>
              </DialogHeader>
              <form onSubmit={(e) => { e.preventDefault(); handleCreateGroup(); }} className="py-6 space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-[10px] font-black text-slate-400 tracking-widest uppercase">Nome do Grupo</Label>
                  <Input 
                    id="name" 
                    placeholder="Ex: Grupo Raposa, Grupo 1..." 
                    className="h-12 bg-slate-50 border-slate-100 rounded-xl focus:ring-blue-500/20"
                    value={newGroupName}
                    onChange={(e) => setNewGroupName(e.target.value)}
                    autoFocus
                  />
                </div>
                <DialogFooter className="pt-4 gap-3 sm:justify-start">
                  <Button 
                    type="submit"
                    disabled={!newGroupName.trim()}
                    className="bg-blue-600 hover:bg-blue-700 text-white font-bold h-12 rounded-xl px-8 flex-1"
                  >
                    Confirmar Criação
                  </Button>
                  <Button 
                    type="button"
                    variant="outline" 
                    onClick={() => setIsCreateDialogOpen(false)}
                    className="border-slate-200 text-slate-600 h-12 rounded-xl px-8"
                  >
                    Cancelar
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
        {groups.length === 0 ? (
          <div className="col-span-full py-24 flex flex-col items-center justify-center bg-white border border-dashed border-slate-200 rounded-[32px] space-y-6">
             <div className="h-20 w-20 rounded-3xl bg-slate-50 flex items-center justify-center">
                <UsersRound className="h-10 w-10 text-slate-300" />
             </div>
             <div className="text-center">
                <h3 className="text-xl font-black text-slate-900">Nenhum grupo configurado</h3>
                <p className="text-slate-400 font-bold max-w-xs mt-2">Os grupos são vinculados aos publicadores no cadastro espiritual.</p>
             </div>
             <Button 
               onClick={() => setIsCreateDialogOpen(true)}
               variant="outline" 
               className="h-11 border-blue-100 text-blue-600 hover:bg-blue-50 font-bold px-8 rounded-xl"
             >
               Começar agora
             </Button>
          </div>
        ) : (
          groups.map((group) => (
             <Card key={group.id} className="border-slate-200 shadow-sm rounded-[32px] overflow-hidden group hover:shadow-xl transition-all">
                <CardContent className="p-0">
                  <div className="p-8 bg-slate-50/50 border-b border-slate-100 flex justify-between items-start">
                    <div className="space-y-1">
                      <h3 className="text-2xl font-black text-slate-900">{group.name}</h3>
                      <p className="text-xs font-black text-blue-600 uppercase tracking-widest">{group.count} Publicadores</p>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => setGroupToDelete({ id: group.id, name: group.name })}
                      className="text-slate-400 hover:text-red-600 transition-colors"
                    >
                      <Trash2 className="h-5 w-5" />
                    </Button>
                  </div>
                  <div className="p-8 space-y-4">
                    <div className="flex items-center gap-3 text-slate-400 mb-4">
                      <Shield className="h-4 w-4" />
                      <p className="text-[10px] font-black uppercase tracking-widest">Responsável: Ancião Local</p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                       {group.members.slice(0, 5).map((m: string) => (
                          <Badge key={m} variant="secondary" className="bg-slate-100 text-slate-600 border-none font-bold py-1.5 px-3 rounded-lg text-[10px]">
                            {m}
                          </Badge>
                       ))}
                       {group.count > 5 && (
                         <Badge variant="outline" className="border-slate-200 text-slate-400 font-bold py-1.5 px-3 rounded-lg text-[10px]">
                           +{group.count - 5} mais
                         </Badge>
                       )}
                    </div>
                    <Button variant="ghost" className="w-full mt-6 h-12 rounded-xl text-slate-500 font-bold group-hover:text-blue-600 group-hover:bg-blue-50 transition-all justify-between">
                      Ver detalhes
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
             </Card>
          ))
        )}
      </div>

      <Dialog open={!!groupToDelete} onOpenChange={(open) => !open && setGroupToDelete(null)}>
        <DialogContent className="sm:max-w-md bg-white border-none rounded-[32px] p-8 shadow-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl font-black text-slate-900 tracking-tight">Excluir Grupo</DialogTitle>
            <p className="text-slate-500 font-bold text-sm">
              Tem certeza que deseja excluir o grupo <span className="text-red-600 font-black">"{groupToDelete?.name}"</span>? Esta ação não pode ser desfeita.
            </p>
          </DialogHeader>
          <DialogFooter className="pt-6 gap-3 sm:justify-start">
            <Button 
              onClick={handleDeleteGroup}
              className="bg-red-600 hover:bg-red-700 text-white font-bold h-12 rounded-xl px-8 flex-1"
            >
              Sim, Excluir
            </Button>
            <Button 
              variant="outline" 
              onClick={() => setGroupToDelete(null)}
              className="border-slate-200 text-slate-600 h-12 rounded-xl px-8"
            >
              Cancelar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
