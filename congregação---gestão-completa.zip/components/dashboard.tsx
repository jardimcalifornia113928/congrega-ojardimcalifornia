'use client';

import React from 'react';
import { 
  Users, 
  FileText, 
  Calendar, 
  BookOpen, 
  TrendingUp,
  ArrowRight,
  Plus
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { useAuth } from '@/components/auth-provider';

interface DashboardProps {
  onNavigate: (tab: string) => void;
}

export function Dashboard({ onNavigate }: DashboardProps) {
  const { user } = useAuth();
  
  const stats = [
    { label: 'Publicadores', value: '0', sub: '0 ativos', icon: Users, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'Pioneiros Regulares', value: '0', sub: 'Ano 25/26', icon: FileText, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'Pioneiros Auxiliares', value: '0', sub: '0 horas', icon: Calendar, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'Estudos Bíblicos', value: '0', sub: 'Média mensal', icon: BookOpen, color: 'text-amber-600', bg: 'bg-amber-50' },
  ];

  const shortcuts = [
    { title: 'Novo Publicador', icon: Plus, tab: 'publishers' },
    { title: 'Lançar Relatórios', icon: FileText, tab: 'field' },
    { title: 'Designar Mecânica', icon: Calendar, tab: 'publishers' },
  ];

  return (
    <div className="space-y-12">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight mb-2">Bom dia!</h1>
          <p className="text-slate-500 font-bold">Congregação Jardim Califórnia — Visão Geral</p>
        </div>
        <div className="flex gap-4">
          <Button variant="outline" className="h-12 border-slate-200 text-slate-600 font-bold rounded-xl gap-2">
            Baixar Backup
          </Button>
          <Button className="h-12 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg shadow-blue-600/20 px-6">
            Gerar S-1
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <Card key={stat.label} className="border-none shadow-sm bg-white rounded-2xl overflow-hidden group hover:shadow-xl hover:shadow-blue-600/5 transition-all">
            <CardContent className="p-8">
              <div className={cn("h-14 w-14 rounded-2xl flex items-center justify-center mb-6 transition-transform group-hover:scale-110", stat.bg)}>
                <stat.icon className={cn("h-7 w-7", stat.color)} />
              </div>
              <div className="space-y-1">
                <p className="text-xs font-black text-slate-400 uppercase tracking-widest">{stat.label}</p>
                <h2 className="text-4xl font-black text-slate-900">{stat.value}</h2>
                <p className="text-[11px] font-bold text-slate-400">{stat.sub}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 bg-white border-slate-200/60 shadow-sm rounded-3xl overflow-hidden">
          <CardHeader className="bg-slate-50/50 border-b border-slate-100 p-8 flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-lg font-black text-slate-900 uppercase tracking-tight">Atalhos Rápidos</CardTitle>
              <p className="text-xs text-slate-400 font-bold">Acesso ágil às funções administrativas</p>
            </div>
          </CardHeader>
          <CardContent className="p-8 grid grid-cols-1 md:grid-cols-3 gap-6">
            {shortcuts.map((s) => (
              <button
                key={s.title}
                onClick={() => onNavigate(s.tab)}
                className="group flex flex-col items-center justify-center p-8 rounded-3xl bg-slate-50/50 border border-slate-100 hover:bg-blue-600 transition-all duration-300 shadow-sm"
              >
                <div className="h-14 w-14 rounded-2xl bg-white flex items-center justify-center mb-4 shadow-sm group-hover:rotate-12 transition-transform">
                  <s.icon className="h-7 w-7 text-blue-600" />
                </div>
                <p className="text-sm font-black text-slate-900 group-hover:text-white transition-colors">{s.title}</p>
              </button>
            ))}
          </CardContent>
        </Card>

        <Card className="bg-white border-slate-200/60 shadow-sm rounded-3xl flex flex-col overflow-hidden">
           <CardHeader className="bg-slate-50/50 border-b border-slate-100 p-8">
            <CardTitle className="text-sm font-black text-slate-900 uppercase tracking-widest">Status Ano de Serviço</CardTitle>
            <p className="text-[11px] text-slate-400 font-bold">Resumo estratégico do ano</p>
          </CardHeader>
          <CardContent className="p-8 flex-1 flex flex-col justify-between">
            <div className="space-y-8">
              {[
                { label: 'Publicadores ativos', value: '0', color: 'bg-emerald-500' },
                { label: 'Irregulares', value: '0', color: 'bg-amber-500' },
                { label: 'Inativos', value: '0', color: 'bg-slate-300' },
              ].map((item) => (
                 <div key={item.label} className="space-y-3">
                    <div className="flex justify-between items-end px-1">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{item.label}</p>
                      <p className="text-sm font-black text-slate-900">{item.value}</p>
                    </div>
                    <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                      <div className={cn("h-full", item.color)} style={{ width: '0%' }} />
                    </div>
                 </div>
              ))}
            </div>

            <div className="pt-8 border-top border-slate-100">
               <div className="flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Total de Horas</p>
                  <h4 className="text-3xl font-black text-slate-900">0</h4>
                </div>
                <div className="h-12 w-12 rounded-full bg-emerald-50 flex items-center justify-center">
                  <TrendingUp className="h-6 w-6 text-emerald-500" />
                </div>
               </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
