'use client';

import React from 'react';
import { FileText, Plus, Printer, Search, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export function FieldReportView() {
  return (
    <div className="space-y-12">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight mb-2">Relatórios de Campo</h1>
          <p className="text-slate-500 font-bold">Consolidação mensal e envio de dados para Betel.</p>
        </div>
        <div className="flex gap-4">
          <Button variant="outline" className="h-12 border-slate-200 text-slate-600 font-bold rounded-xl gap-2 px-6">
            <Download className="h-4 w-4" />
            Exportar CSV
          </Button>
          <Button className="h-12 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg shadow-blue-600/20 px-8">
            <Plus className="h-4 w-4 mr-2" />
            Lançar Coletivo
          </Button>
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-[32px] overflow-hidden">
        <div className="p-8 border-b border-slate-100 flex justify-between items-center">
          <h3 className="text-lg font-black text-slate-900">Atividade Recente</h3>
          <div className="relative w-64">
            <Search className="absolute left-4 top-3 h-4 w-4 text-slate-400" />
            <Input placeholder="Buscar mês..." className="pl-12 h-11 bg-slate-50 border-none rounded-xl" />
          </div>
        </div>
        <div className="p-24 flex flex-col items-center justify-center text-center space-y-6">
          <div className="h-20 w-20 rounded-3xl bg-slate-50 flex items-center justify-center">
            <FileText className="h-10 w-10 text-slate-300" />
          </div>
          <div>
            <h3 className="text-xl font-black text-slate-900">Nenhum relatório este mês</h3>
            <p className="text-slate-400 font-bold max-w-xs mt-2">Aguardando o fechamento do período para processar os totais.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
