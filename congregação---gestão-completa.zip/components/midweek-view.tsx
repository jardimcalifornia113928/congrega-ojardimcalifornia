'use client';

import React from 'react';
import { Calendar, Plus, Printer, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';

export function MidweekView() {
  return (
    <div className="space-y-12">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight mb-2">Reunião de Meio de Semana</h1>
          <p className="text-slate-500 font-bold">Designações: Tesouros, Vida e Ministério, Nossa Vida Cristã.</p>
        </div>
        <div className="flex gap-4">
          <Button variant="outline" className="h-12 border-slate-200 text-slate-600 font-bold rounded-xl gap-2 px-6">
            <Printer className="h-4 w-4" />
            Imprimir Programação
          </Button>
          <Button className="h-12 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg shadow-blue-600/20 px-8">
            <Plus className="h-4 w-4 mr-2" />
            Nova Reunião
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <div className="col-span-full py-24 flex flex-col items-center justify-center bg-white border border-dashed border-slate-200 rounded-[32px] space-y-6">
          <div className="h-20 w-20 rounded-3xl bg-slate-50 flex items-center justify-center">
            <Calendar className="h-10 w-10 text-slate-300" />
          </div>
          <div className="text-center">
            <h3 className="text-xl font-black text-slate-900">Nenhuma reunião agendada</h3>
            <p className="text-slate-400 font-bold max-w-xs mt-2">Clique em "Nova Reunião" para começar a designar as partes.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
