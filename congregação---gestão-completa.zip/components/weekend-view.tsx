'use client';

import React from 'react';
import { Calendar, Plus, Printer } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function WeekendView() {
  return (
    <div className="space-y-12">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight mb-2">Reunião de Fim de Semana</h1>
          <p className="text-slate-500 font-bold">Gestão de Discursos Públicos e Estudo de A Sentinela.</p>
        </div>
        <div className="flex gap-4">
          <Button variant="outline" className="h-12 border-slate-200 text-slate-600 font-bold rounded-xl gap-2 px-6">
            <Printer className="h-4 w-4" />
            Imprimir Quadro
          </Button>
          <Button className="h-12 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg shadow-blue-600/20 px-8">
            <Plus className="h-4 w-4 mr-2" />
            Nova Reunião
          </Button>
        </div>
      </div>

      <div className="py-24 flex flex-col items-center justify-center bg-white border border-dashed border-slate-200 rounded-[32px] space-y-6">
        <div className="h-20 w-20 rounded-3xl bg-slate-50 flex items-center justify-center">
          <Calendar className="h-10 w-10 text-slate-300" />
        </div>
        <div className="text-center">
          <h3 className="text-xl font-black text-slate-900">Agenda vazia</h3>
          <p className="text-slate-400 font-bold max-w-xs mt-2">Nenhum discurso público agendado para as próximas semanas.</p>
        </div>
      </div>
    </div>
  );
}
