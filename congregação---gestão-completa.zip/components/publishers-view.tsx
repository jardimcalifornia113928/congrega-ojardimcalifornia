'use client';

import React, { useState } from 'react';
import { 
  Search, 
  Plus, 
  Save, 
  UserPlus, 
  Filter, 
  Trash2,
  Calendar,
  CheckCircle2,
  MoreVertical,
  Clock,
  Printer,
  Users,
  Loader2
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { cn } from '@/lib/utils';
import { db } from '@/lib/firebase';
import { useAuth } from '@/components/auth-provider';
import { handleFirestoreError, OperationType } from '@/lib/firebase-utils';
import { toast } from 'sonner';
import { 
  collection, 
  onSnapshot, 
  query, 
  orderBy, 
  where,
  addDoc, 
  updateDoc, 
  doc, 
  deleteDoc,
  serverTimestamp
} from 'firebase/firestore';

import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter 
} from '@/components/ui/dialog';

export function PublishersView() {
  const [selectedPublisherId, setSelectedPublisherId] = useState<string | null>(null);
  const [publisherData, setPublisherData] = useState<any>({
    firstName: "",
    middleName: "",
    lastName: "",
    phone: "",
    secondaryPhone: "",
    profession: "",
    address: "",
    birthDate: "",
    gender: "masculino",
    status: "ativo",
    groupId: "",
    responsibility: "publicador",
    pioneerType: "nao",
    baptismDate: "",
    tags: [],
    designations: []
  });
  const [publishers, setPublishers] = useState<any[]>([]);
  const [groups, setGroups] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { user } = useAuth();

  // Fetch Publishers
  React.useEffect(() => {
    if (!user) {
      setPublishers([]);
      setIsLoading(false);
      return;
    }

    const q = query(
      collection(db, 'publishers'), 
      where('ownerId', '==', user.uid)
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const pubs = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })).sort((a: any, b: any) => (a.firstName || "").localeCompare(b.firstName || ""));
      setPublishers(pubs);
      setIsLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'publishers');
      setIsLoading(false);
    });
    return () => unsubscribe();
  }, [user]);

  // Fetch Groups
  React.useEffect(() => {
    if (!user) {
      setGroups([]);
      return;
    }

    const q = query(
      collection(db, 'groups'), 
      where('ownerId', '==', user.uid)
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const gs = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })).sort((a: any, b: any) => (a.name || "").localeCompare(b.name || ""));
      setGroups(gs);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'groups');
    });
    return () => unsubscribe();
  }, [user]);

  // Load selected publisher data
  React.useEffect(() => {
    if (selectedPublisherId) {
      const pub = publishers.find(p => p.id === selectedPublisherId);
      if (pub) {
        setPublisherData(pub);
      }
    } else {
      setPublisherData({
        firstName: "",
        middleName: "",
        lastName: "",
        phone: "",
        secondaryPhone: "",
        profession: "",
        address: "",
        birthDate: "",
        gender: "masculino",
        status: "ativo",
        groupId: "",
        responsibility: "publicador",
        pioneerType: "nao",
        baptismDate: "",
        tags: [],
        designations: []
      });
    }
  }, [selectedPublisherId, publishers]);

  const handleSave = async () => {
    if (!user) {
      toast.error("Você precisa estar logado para salvar!");
      return;
    }
    if (!publisherData.firstName?.trim() || !publisherData.lastName?.trim()) {
      toast.error("Nome e Sobrenome são obrigatórios!");
      return;
    }
    const toastId = toast.loading(selectedPublisherId ? "Atualizando..." : "Cadastrando...");
    try {
      // Remove any unwanted fields from data
      const { id, createdAt, updatedAt, ...pureData } = publisherData;
      
      if (selectedPublisherId) {
        await updateDoc(doc(db, 'publishers', selectedPublisherId), {
          ...pureData,
          updatedAt: serverTimestamp()
        });
      } else {
        const docRef = await addDoc(collection(db, 'publishers'), {
          ...pureData,
          ownerId: user.uid,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        });
        setSelectedPublisherId(docRef.id);
      }
      toast.success(selectedPublisherId ? "Alterações salvas!" : "Publicador cadastrado com sucesso!", { id: toastId });
    } catch (error: any) {
      console.error("Save error detail:", error);
      let msg = "Erro desconhecido";
      if (error.message?.includes("permission-denied")) {
        msg = "Permissão negada no banco de dados.";
      } else if (error.message) {
        msg = error.message;
      }
      toast.error(`Erro ao salvar: ${msg}`, { id: toastId });
    }
  };

  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);

  const handleDelete = async () => {
    if (!selectedPublisherId) return;
    const pub = publishers.find(p => p.id === selectedPublisherId);
    if (!pub) return;
    
    const toastId = toast.loading("Excluindo cadastro...");
    try {
      await deleteDoc(doc(db, 'publishers', selectedPublisherId));
      setSelectedPublisherId(null);
      setIsDeleteDialogOpen(false);
      toast.success("Cadastro excluído com sucesso!", { id: toastId });
    } catch (error: any) {
      console.error("Delete publisher error:", error);
      toast.error(`Erro ao excluir: ${error.message || "Erro desconhecido"}`, { id: toastId });
      handleFirestoreError(error, OperationType.DELETE, `publishers/${selectedPublisherId}`);
    }
  };

  const handleNew = () => {
    setSelectedPublisherId(null);
  };

  // State for registries (simplified for UI demonstration)
  const serviceYear = "2025/2026";
  const hoursGoal = 850;
  const currentTotalHours = 0; // In a real app, this would be computed
  const remainingHours = hoursGoal - currentTotalHours;

  return (
    <div className="flex-1 flex flex-col gap-8 min-h-0">
      <div className="flex justify-between items-end shrink-0">
        <div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight mb-2">Publicadores</h1>
          <p className="text-slate-500 font-bold">Gestão completa do corpo de publicadores.</p>
        </div>
        <div className="flex gap-4">
          <Button variant="outline" className="border-slate-200 text-slate-600 font-bold h-12 rounded-xl gap-2 px-6">
            Relatórios em Lote
          </Button>
          <Button 
            onClick={() => setIsDeleteDialogOpen(true)}
            disabled={!selectedPublisherId}
            variant="outline" 
            className="border-red-200 text-red-600 hover:bg-red-50 font-bold h-12 rounded-xl gap-2 px-6"
          >
            <Trash2 className="h-4 w-4" />
            Excluir Cadastro
          </Button>
          <Button 
            onClick={handleSave}
            className="bg-blue-600 hover:bg-blue-700 text-white font-bold h-12 rounded-xl px-8 shadow-lg shadow-blue-600/20 gap-2"
          >
            <Save className="h-4 w-4" />
            {selectedPublisherId ? "Salvar Alterações" : "Cadastrar Publicador"}
          </Button>
        </div>
      </div>

      <div className="flex-1 flex gap-8 overflow-hidden">
        {/* List Card */}
        <Card className="w-96 bg-white border-slate-200 shadow-sm rounded-3xl overflow-hidden flex flex-col">
          <div className="p-6 border-b border-slate-100 space-y-4">
            <div className="relative">
              <Search className="absolute left-4 top-3 h-4 w-4 text-slate-400" />
              <Input placeholder="Buscar por nome..." className="pl-12 h-11 bg-slate-50 border-slate-100 rounded-xl focus-visible:ring-blue-500/20" />
            </div>
            <div className="flex gap-2">
              <Button 
                onClick={handleNew}
                className="flex-1 h-12 bg-blue-600 hover:bg-blue-700 gap-2 font-bold rounded-xl shadow-md shadow-blue-600/10"
              >
                <Plus className="h-4 w-4" />
                Novo
              </Button>
            </div>
          </div>
          <ScrollArea className="flex-1">
            {isLoading ? (
               <div className="p-12 flex justify-center">
                 <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
               </div>
            ) : publishers.length === 0 ? (
               <div className="p-12 flex flex-col items-center justify-center text-center space-y-4">
                 <div className="h-16 w-16 rounded-full bg-slate-50 flex items-center justify-center">
                   <Users className="h-8 w-8 text-slate-300" />
                 </div>
                 <div>
                   <p className="text-slate-400 font-bold text-sm">Nenhum cadastro encontrado</p>
                   <p className="text-xs text-slate-300 mt-1">Comece cadastrando um novo publicador.</p>
                 </div>
               </div>
            ) : (
              <div className="p-4 space-y-2">
                {publishers.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setSelectedPublisherId(p.id)}
                    className={cn(
                      "w-full text-left p-4 rounded-2xl transition-all border",
                      selectedPublisherId === p.id 
                        ? "bg-blue-50 border-blue-100 shadow-sm" 
                        : "border-transparent text-slate-600 hover:bg-slate-50"
                    )}
                  >
                    <p className="font-bold text-slate-900">{p.firstName} {p.lastName}</p>
                    <p className="text-[10px] uppercase font-black text-slate-400 tracking-widest mt-1">
                      Grupo: {groups.find(g => g.id === p.groupId)?.name || "Não atribuído"}
                    </p>
                  </button>
                ))}
              </div>
            )}
          </ScrollArea>
        </Card>

        {/* Form Area */}
        <div className="flex-1 bg-white border border-slate-200 shadow-sm rounded-3xl overflow-hidden flex flex-col h-full min-h-0">
          <Tabs defaultValue="personal" className="flex-1 flex flex-col min-h-0 overflow-hidden">
            <div className="px-8 pt-6 border-b border-slate-100 bg-slate-50/50 shrink-0">
              <TabsList className="bg-transparent gap-8 h-auto p-0">
                <TabsTrigger value="personal" className="bg-transparent border-b-2 border-transparent data-[state=active]:border-blue-600 data-[state=active]:text-blue-600 rounded-none h-12 px-2 font-bold text-slate-400 transition-all cursor-pointer outline-none">Dados Pessoais</TabsTrigger>
                <TabsTrigger value="spiritual" className="bg-transparent border-b-2 border-transparent data-[state=active]:border-blue-600 data-[state=active]:text-blue-600 rounded-none h-12 px-2 font-bold text-slate-400 transition-all cursor-pointer outline-none">Espiritual</TabsTrigger>
                <TabsTrigger value="designation" className="bg-transparent border-b-2 border-transparent data-[state=active]:border-blue-600 data-[state=active]:text-blue-600 rounded-none h-12 px-2 font-bold text-slate-400 transition-all cursor-pointer outline-none">Designação</TabsTrigger>
                <TabsTrigger value="registry" className="bg-transparent border-b-2 border-transparent data-[state=active]:border-blue-600 data-[state=active]:text-blue-600 rounded-none h-12 px-2 font-bold text-slate-400 transition-all cursor-pointer outline-none">Registro (S-21)</TabsTrigger>
              </TabsList>
            </div>

            <ScrollArea className="flex-1 w-full h-full">
              <div className="p-10">
                <div className="max-w-4xl mx-auto">
                  <TabsContent value="personal" className="m-0 space-y-10 outline-none">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div className="space-y-3">
                      <Label className="text-[10px] font-black text-slate-400 tracking-widest uppercase">Primeiro Nome</Label>
                      <Input 
                        value={publisherData.firstName}
                        onChange={(e) => setPublisherData({ ...publisherData, firstName: e.target.value })}
                        placeholder="Nome" 
                        className="h-12 bg-slate-50 border-slate-100 rounded-xl focus:ring-blue-500/20" 
                      />
                    </div>
                    <div className="space-y-3">
                      <Label className="text-[10px] font-black text-slate-400 tracking-widest uppercase">Nome do Meio</Label>
                      <Input 
                        value={publisherData.middleName}
                        onChange={(e) => setPublisherData({ ...publisherData, middleName: e.target.value })}
                        placeholder="Nome do meio" 
                        className="h-12 bg-slate-50 border-slate-100 rounded-xl focus:ring-blue-500/20" 
                      />
                    </div>
                    <div className="space-y-3">
                      <Label className="text-[10px] font-black text-slate-400 tracking-widest uppercase">Sobrenome</Label>
                      <Input 
                        value={publisherData.lastName}
                        onChange={(e) => setPublisherData({ ...publisherData, lastName: e.target.value })}
                        placeholder="Sobrenome" 
                        className="h-12 bg-slate-50 border-slate-100 rounded-xl focus:ring-blue-500/20" 
                      />
                    </div>
                    <div className="space-y-3">
                      <Label className="text-[10px] font-black text-slate-400 tracking-widest uppercase">Celular Principal</Label>
                      <Input 
                        value={publisherData.phone}
                        onChange={(e) => setPublisherData({ ...publisherData, phone: e.target.value })}
                        placeholder="(00) 00000-0000" 
                        className="h-12 bg-slate-50 border-slate-100 rounded-xl focus:ring-blue-500/20" 
                      />
                    </div>
                    <div className="space-y-3">
                      <Label className="text-[10px] font-black text-slate-400 tracking-widest uppercase">Recado / Outro</Label>
                      <Input 
                        value={publisherData.secondaryPhone}
                        onChange={(e) => setPublisherData({ ...publisherData, secondaryPhone: e.target.value })}
                        placeholder="(00) 00000-0000" 
                        className="h-12 bg-slate-50 border-slate-100 rounded-xl focus:ring-blue-500/20" 
                      />
                    </div>
                    <div className="space-y-3">
                      <Label className="text-[10px] font-black text-slate-400 tracking-widest uppercase">Profissão</Label>
                      <Input 
                        value={publisherData.profession}
                        onChange={(e) => setPublisherData({ ...publisherData, profession: e.target.value })}
                        placeholder="Cargo" 
                        className="h-12 bg-slate-50 border-slate-100 rounded-xl focus:ring-blue-500/20" 
                      />
                    </div>
                    <div className="md:col-span-3 space-y-3">
                      <Label className="text-[10px] font-black text-slate-400 tracking-widest uppercase">Residência / Endereço</Label>
                      <Input 
                        value={publisherData.address}
                        onChange={(e) => setPublisherData({ ...publisherData, address: e.target.value })}
                        placeholder="Rua, Número, Bairro..." 
                        className="h-12 bg-slate-50 border-slate-100 rounded-xl focus:ring-blue-500/20" 
                      />
                    </div>
                    <div className="space-y-3">
                      <Label className="text-[10px] font-black text-slate-400 tracking-widest uppercase">Nascimento</Label>
                      <Input 
                        value={publisherData.birthDate}
                        onChange={(e) => setPublisherData({ ...publisherData, birthDate: e.target.value })}
                        type="date" 
                        className="h-12 bg-slate-50 border-slate-100 rounded-xl" 
                      />
                    </div>
                    <div className="space-y-3">
                      <Label className="text-[10px] font-black text-slate-400 tracking-widest uppercase">Gênero</Label>
                      <Select 
                        value={publisherData.gender}
                        onValueChange={(val) => setPublisherData({ ...publisherData, gender: val })}
                      >
                        <SelectTrigger className="h-12 bg-slate-50 border-slate-100 rounded-xl">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="masculino">Masculino</SelectItem>
                          <SelectItem value="feminino">Feminino</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="spiritual" className="m-0 space-y-10">
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-3">
                      <Label className="text-[10px] font-black text-slate-400 tracking-widest uppercase">Situação na Congregação</Label>
                      <Select 
                        value={publisherData.status} 
                        onValueChange={(val) => setPublisherData({ ...publisherData, status: val })}
                      >
                        <SelectTrigger className="h-12 bg-slate-50 border-slate-100 rounded-xl">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="ativo">Ativo</SelectItem>
                          <SelectItem value="inativo">Inativo</SelectItem>
                          <SelectItem value="removido">Removido</SelectItem>
                          <SelectItem value="mudou">Mudou</SelectItem>
                        </SelectContent>
                      </Select>
                      {publisherData.status === 'inativo' && (
                        <p className="text-[10px] font-bold text-red-500 uppercase bg-red-50 p-2 rounded-lg">Sistema detectou 6 meses sem atividade corporativa</p>
                      )}
                    </div>
                    <div className="space-y-3">
                      <Label className="text-[10px] font-black text-slate-400 tracking-widest uppercase">Grupo de Campo</Label>
                      <Select 
                        value={publisherData.groupId} 
                        onValueChange={(val) => setPublisherData({ ...publisherData, groupId: val })}
                      >
                        <SelectTrigger className="h-12 bg-slate-50 border-slate-100 rounded-xl">
                          <SelectValue placeholder="Selecione um grupo" />
                        </SelectTrigger>
                        <SelectContent>
                          {groups.map((group) => (
                            <SelectItem key={group.id} value={group.id}>{group.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-3">
                      <Label className="text-[10px] font-black text-slate-400 tracking-widest uppercase">Responsabilidade</Label>
                      <Select 
                        value={publisherData.responsibility} 
                        onValueChange={(val) => setPublisherData({ ...publisherData, responsibility: val })}
                      >
                        <SelectTrigger className="h-12 bg-slate-50 border-slate-100 rounded-xl">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="publicador">Publicador</SelectItem>
                          <SelectItem value="servo">Servo Ministerial</SelectItem>
                          <SelectItem value="anciao">Ancião</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-3">
                      <Label className="text-[10px] font-black text-slate-400 tracking-widest uppercase">Tipo de Pioneiro</Label>
                      <Select 
                        value={publisherData.pioneerType} 
                        onValueChange={(val) => setPublisherData({ ...publisherData, pioneerType: val })}
                      >
                        <SelectTrigger className="h-12 bg-slate-50 border-slate-100 rounded-xl">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="nao">Não é pioneiro</SelectItem>
                          <SelectItem value="auxiliar">Auxiliar</SelectItem>
                          <SelectItem value="regular">Pioneiro Regular</SelectItem>
                          <SelectItem value="especial">Pioneiro Especial</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-3">
                      <Label className="text-[10px] font-black text-slate-400 tracking-widest uppercase">Data de Batismo</Label>
                      <Input 
                        value={publisherData.baptismDate}
                        onChange={(e) => setPublisherData({ ...publisherData, baptismDate: e.target.value })}
                        type="date" 
                        className="h-12 bg-slate-50 border-slate-100 rounded-xl" 
                      />
                    </div>
                   </div>

                   <div className="bg-slate-50 p-8 rounded-3xl border border-slate-100 space-y-6">
                      <h4 className="text-xs font-black text-slate-900 uppercase tracking-widest">Outras Informações</h4>
                      <div className="grid grid-cols-2 gap-4">
                        {[
                          "Outras Ovelhas", "Ungido", "Batizado", "Publicador não batizado", "Menor", "Estudante"
                        ].map((item) => (
                           <div key={item} className="flex items-center space-x-3 p-4 bg-white rounded-2xl border border-slate-100 transition-colors hover:bg-slate-50">
                              <Checkbox 
                                id={item} 
                                className="h-5 w-5 border-slate-200" 
                                checked={publisherData.tags?.includes(item)}
                                onCheckedChange={(checked) => {
                                  const currentTags = publisherData.tags || [];
                                  if (checked) {
                                    setPublisherData({ ...publisherData, tags: [...currentTags, item] });
                                  } else {
                                    setPublisherData({ ...publisherData, tags: currentTags.filter((t: string) => t !== item) });
                                  }
                                }}
                              />
                              <label htmlFor={item} className="text-sm font-bold text-slate-700 cursor-pointer">{item}</label>
                           </div>
                        ))}
                      </div>
                   </div>
                </TabsContent>

                <TabsContent value="designation" className="m-0 space-y-10">
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      {[
                        { title: "Tesouros da Palavra", items: ["Presidente", "Orações", "Joias espirituais", "Discurso 10min", "Leitura da Bíblia"] },
                        { title: "Vida e Ministério", items: ["Iniciando conversas", "Cultivando o interesse", "Fazendo discípulos", "Explicando suas crenças", "Discurso", "Estudo Bíblico", "Ajudante"] },
                        { title: "Nossa vida cristã", items: ["Partes", "Estudo Bíblico", "Leitor"] },
                        { title: "Fim de semana", items: ["Orador local", "Orador fora", "Presidente", "Oração inicial", "Dirigente A Sentinela", "Leitor", "Oração final"] },
                        { title: "Serviço de campo", items: ["Testemunho público", "Dirigente de campo", "Pessoa-chave"] },
                        { title: "Designação Mecânica", items: ["Indicador", "Microfones", "Som", "Palco"] },
                      ].map((sec) => (
                        <Card key={sec.title} className="bg-white border-slate-100 shadow-sm rounded-3xl overflow-hidden group hover:border-blue-200 transition-all">
                          <div className="px-6 py-4 bg-slate-50/50 border-b border-slate-100">
                            <h4 className="text-xs font-black text-slate-900 uppercase tracking-widest">{sec.title}</h4>
                          </div>
                          <CardContent className="p-6">
                            <div className="space-y-4">
                              {sec.items.map((item) => (
                                <div key={item} className="flex items-center space-x-3">
                                  <Checkbox 
                                    id={item} 
                                    className="h-5 w-5 border-slate-200" 
                                    checked={publisherData.designations?.includes(item)}
                                    onCheckedChange={(checked) => {
                                      const currentDes = publisherData.designations || [];
                                      if (checked) {
                                        setPublisherData({ ...publisherData, designations: [...currentDes, item] });
                                      } else {
                                        setPublisherData({ ...publisherData, designations: currentDes.filter((d: string) => d !== item) });
                                      }
                                    }}
                                  />
                                  <label htmlFor={item} className="text-sm font-bold text-slate-600 cursor-pointer">{item}</label>
                                </div>
                              ))}
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                   </div>
                </TabsContent>

                <TabsContent value="registry" className="m-0 space-y-10">
                   {publisherData.pioneerType === "regular" && (
                     <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <Card className="bg-blue-600 text-white border-none shadow-xl shadow-blue-600/20 rounded-3xl">
                          <CardContent className="p-8">
                            <div className="flex items-center gap-3 opacity-70 mb-2">
                                <Clock className="h-4 w-4" />
                                <p className="text-[10px] font-black uppercase tracking-widest">Objetivo Anual</p>
                            </div>
                            <h3 className="text-5xl font-black">{hoursGoal}h</h3>
                          </CardContent>
                        </Card>
                        <Card className="bg-slate-900 text-white border-none shadow-xl shadow-slate-900/10 rounded-3xl">
                          <CardContent className="p-8">
                            <div className="flex items-center gap-3 opacity-70 mb-2">
                                <Plus className="h-4 w-4" />
                                <p className="text-[10px] font-black uppercase tracking-widest">Horas Lançadas</p>
                            </div>
                            <h3 className="text-5xl font-black">{currentTotalHours}h</h3>
                          </CardContent>
                        </Card>
                        <Card className="bg-white border-slate-200 shadow-xl shadow-slate-200/10 rounded-3xl">
                          <CardContent className="p-8">
                            <div className="flex items-center gap-3 text-slate-400 mb-2">
                                <Clock className="h-4 w-4" />
                                <p className="text-[10px] font-black uppercase tracking-widest">Restante</p>
                            </div>
                            <h3 className="text-5xl font-black text-slate-900">{remainingHours}h</h3>
                          </CardContent>
                        </Card>
                     </div>
                   )}

                   <div className="flex justify-between items-center bg-blue-50/50 p-8 rounded-3xl border border-blue-100">
                      <div>
                        <p className="text-sm font-black text-blue-900 uppercase tracking-tight">Ano de serviço {serviceYear}</p>
                        <p className="text-xs text-blue-600/80 font-bold mt-1">Lançamento mensal de atividades de campo.</p>
                      </div>
                      <div className="flex gap-3">
                         <Button variant="outline" className="bg-white border-blue-200 text-blue-600 hover:bg-blue-100 h-12 gap-2 font-bold px-6 rounded-xl text-xs uppercase tracking-widest">
                          <Printer className="h-4 w-4" />
                          Imprimir S-21
                        </Button>
                      </div>
                   </div>

                   <div className="rounded-3xl border border-slate-100 overflow-hidden bg-white shadow-sm">
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader className="bg-slate-50/80">
                          <TableRow className="border-slate-100 hover:bg-transparent">
                            <TableHead className="text-[10px] font-black text-slate-500 uppercase h-14 px-8 whitespace-nowrap">Mês</TableHead>
                            <TableHead className="text-[10px] font-black text-slate-500 uppercase h-14 text-center whitespace-nowrap">Participou</TableHead>
                            <TableHead className="text-[10px] font-black text-slate-500 uppercase h-14 text-center whitespace-nowrap">Estudos</TableHead>
                            <TableHead className="text-[10px] font-black text-slate-500 uppercase h-14 text-center whitespace-nowrap">Auxiliar</TableHead>
                            <TableHead className="text-[10px] font-black text-slate-500 uppercase h-14 text-center whitespace-nowrap">Horas</TableHead>
                            <TableHead className="text-[10px] font-black text-slate-500 uppercase h-14 px-8 whitespace-nowrap">Observações</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {["Setembro", "Outubro", "Novembro", "Dezembro", "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto"].map((m) => (
                            <TableRow key={m} className="border-slate-100 hover:bg-slate-50/50 transition-colors h-16">
                              <TableCell className="text-sm font-bold text-slate-900 px-8">{m}</TableCell>
                              <TableCell className="text-center">
                                <div className="flex justify-center">
                                  <Checkbox className="h-5 w-5 border-slate-200 data-[state=checked]:bg-blue-600" />
                                </div>
                              </TableCell>
                              <TableCell className="text-center">
                                <Input type="number" className="w-20 mx-auto h-12 text-center bg-white border-slate-200 text-sm font-bold rounded-xl" defaultValue={0} />
                              </TableCell>
                              <TableCell className="text-center">
                                <div className="flex justify-center">
                                  <Checkbox className="h-5 w-5 border-slate-200 data-[state=checked]:bg-blue-600" />
                                </div>
                              </TableCell>
                              <TableCell className="text-center">
                                 <Input type="number" className="w-24 mx-auto h-12 text-center bg-white border-slate-200 text-sm font-bold rounded-xl" defaultValue={0} />
                              </TableCell>
                              <TableCell className="px-8">
                                <Input className="h-12 bg-white border-slate-200 text-xs font-bold rounded-xl min-w-[200px]" placeholder="Detalhes..." />
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                   </div>
                </TabsContent>
              </div>
            </div>
          </ScrollArea>
        </Tabs>
      </div>
      </div>

      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="sm:max-w-md bg-white border-none rounded-[32px] p-8 shadow-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl font-black text-slate-900 tracking-tight">Excluir Cadastro</DialogTitle>
            <p className="text-slate-500 font-bold text-sm">
              Tem certeza que deseja excluir o cadastro de <span className="text-red-600 font-black">"{publishers.find(p => p.id === selectedPublisherId)?.firstName} {publishers.find(p => p.id === selectedPublisherId)?.lastName}"</span>? Esta ação não pode ser desfeita.
            </p>
          </DialogHeader>
          <DialogFooter className="pt-6 gap-3 sm:justify-start">
            <Button 
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700 text-white font-bold h-12 rounded-xl px-8 flex-1"
            >
              Sim, Excluir
            </Button>
            <Button 
              variant="outline" 
              onClick={() => setIsDeleteDialogOpen(false)}
              className="border-slate-200 text-slate-600 h-12 rounded-xl px-8"
            >
              Cancelar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
