'use client';

import React from 'react';
import { 
  BarChart3, 
  Users, 
  Calendar, 
  FileText, 
  Settings, 
  LogOut, 
  UsersRound,
  LayoutDashboard,
  Printer
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAuth } from '@/components/auth-provider';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

interface SidebarProps {
  activeTab: string;
  onNavigate: (tab: string) => void;
}

export function Sidebar({ activeTab, onNavigate }: SidebarProps) {
  const { logout, user } = useAuth();
  
  const groups = [
    { title: 'MENU', items: [
      { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    ]},
    { title: 'GESTÃO', items: [
      { id: 'publishers', label: 'Publicadores', icon: Users },
      { id: 'groups', label: 'Grupo de Campo', icon: UsersRound },
    ]},
    { title: 'ATIVIDADES', items: [
      { id: 'midweek', label: 'Meio de Semana', icon: Calendar },
      { id: 'weekend', label: 'Fim de Semana', icon: Calendar },
      { id: 'field', label: 'Relatórios de Campo', icon: FileText },
      { id: 'prints', label: 'Impressões', icon: Printer },
    ]},
    { title: 'SISTEMA', items: [
      { id: 'settings', label: 'Configurações', icon: Settings },
    ]},
  ];

  return (
    <aside className="w-80 bg-white border-r border-slate-200 flex flex-col h-full shadow-xl shadow-slate-200/20">
      <div className="p-10">
        <div className="bg-blue-600 h-14 w-14 rounded-2xl flex items-center justify-center text-white font-black text-3xl shadow-lg shadow-blue-600/30 mb-6">C</div>
        <p className="text-[11px] font-black text-slate-400 tracking-[0.2em] uppercase">Congregação Admin</p>
      </div>

      <nav className="flex-1 px-6 space-y-10 overflow-y-auto">
        {groups.map((group) => (
          <div key={group.title} className="space-y-4">
            <h3 className="px-4 text-[10px] font-black text-slate-400 tracking-widest uppercase opacity-70">{group.title}</h3>
            {group.items.map((item) => (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={cn(
                  "w-full flex items-center gap-4 px-4 py-3.5 rounded-2xl text-[13px] font-bold transition-all duration-300",
                  activeTab === item.id 
                    ? "bg-blue-600 text-white shadow-lg shadow-blue-600/20 translate-x-1" 
                    : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
                )}
              >
                <item.icon className="h-5 w-5" />
                {item.label}
              </button>
            ))}
          </div>
        ))}
      </nav>

      <div className="p-6 mt-auto border-t border-slate-100 space-y-4">
        {user && (
          <div className="flex items-center gap-4 px-4 py-4 bg-slate-50/80 rounded-3xl border border-slate-200/50">
            <Avatar className="h-12 w-12 border-2 border-white shadow-md">
              <AvatarImage src={user.photoURL || undefined} alt={user.displayName || 'Usuário'} />
              <AvatarFallback className="bg-blue-100 text-blue-600 font-bold">
                {user.displayName?.substring(0, 2).toUpperCase() || 'U'}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-black text-slate-900 truncate">{user.displayName}</p>
              <p className="text-[10px] font-black text-blue-600 truncate uppercase mt-0.5 tracking-tighter">Administrador</p>
            </div>
          </div>
        )}
        <button 
          onClick={logout}
          className="w-full flex items-center gap-4 px-5 py-4 rounded-2xl text-[13px] font-bold text-slate-400 hover:bg-red-50 hover:text-red-600 transition-all group"
        >
          <LogOut className="h-5 w-5 group-hover:rotate-12 transition-transform" />
          Sair com Segurança
        </button>
      </div>
    </aside>
  );
}
