'use client';

import React from 'react';
import { Settings, Shield, Bell, Database, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';

export function SettingsView() {
  return (
    <div className="space-y-12">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight mb-2">Configurações</h1>
          <p className="text-slate-500 font-bold">Gerencie as preferências globais do sistema.</p>
        </div>
        <Button className="h-12 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg shadow-blue-600/20 px-8 gap-2">
          <Save className="h-4 w-4" />
          Salvar Tudo
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card className="border-slate-200 shadow-sm rounded-[32px] overflow-hidden">
          <CardHeader className="bg-slate-50/50 border-b border-slate-100 p-8">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-blue-50 flex items-center justify-center">
                <Shield className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <CardTitle className="text-sm font-black text-slate-900 uppercase tracking-widest">Congregação</CardTitle>
                <p className="text-[10px] text-slate-400 font-bold">Dados básicos da conta local</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-8 space-y-6">
            <div className="space-y-3">
              <Label className="text-[10px] font-black text-slate-400 tracking-widest uppercase">Nome da Congregação</Label>
              <Input defaultValue="Jardim Califórnia" className="h-12 bg-slate-50 border-slate-100 rounded-xl" />
            </div>
            <div className="space-y-3">
              <Label className="text-[10px] font-black text-slate-400 tracking-widest uppercase">Circuito</Label>
              <Input defaultValue="SP-00" className="h-12 bg-slate-50 border-slate-100 rounded-xl" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-slate-200 shadow-sm rounded-[32px] overflow-hidden">
          <CardHeader className="bg-slate-50/50 border-b border-slate-100 p-8">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-emerald-50 flex items-center justify-center">
                <Database className="h-5 w-5 text-emerald-600" />
              </div>
              <div>
                <CardTitle className="text-sm font-black text-slate-900 uppercase tracking-widest">Base de Dados</CardTitle>
                <p className="text-[10px] text-slate-400 font-bold">Manutenção e backups</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-8 space-y-6">
            <p className="text-sm text-slate-500 font-medium">Sincronização ativa com Firebase Firestore.</p>
            <Button variant="outline" className="w-full h-12 border-slate-200 text-slate-600 font-bold rounded-xl gap-2">
              Limpar Cache Local
            </Button>
            <Button variant="outline" className="w-full h-12 border-slate-200 text-slate-600 font-bold rounded-xl gap-2">
              Validar Integridade
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
